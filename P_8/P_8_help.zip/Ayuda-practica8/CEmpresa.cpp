template<class T>
CEmpresa<T>::CEmpresa(const CEmpresa<T> &a) {
	*this = a;
}

// Operador =



// Destructor



// AgregarElemento



// GetElemento



// Operador de indexaci�n: []
